package com.example.dt;

import java.util.ArrayList;

class Cafe {
    private IIsland island;
    private ArrayList<SoftEngg> engineers;
    private City city;

    public Cafe(City city) {
        this.city = city;
    }

    public IIsland getIsland() {
        return island;
    }


    public ArrayList<SoftEngg> getEngineers() {
        return engineers;
    }

    public void setEngineers(ArrayList<SoftEngg> engineers) {
        this.engineers = engineers;
    }

    public void generateNews(String news){
        alertCity(news);
    }

    private void alertCity(String news) {
        this.city.updateNews(news,this);
    }

    public void setCityNews(String s) {
        this.island.setCityNews(s);
    }
}
