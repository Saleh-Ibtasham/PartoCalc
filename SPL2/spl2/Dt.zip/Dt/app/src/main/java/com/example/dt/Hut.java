package com.example.dt;

public class Hut implements HutPlan {

    private Basement basement;
    private Roof roof;
    private Wall wall;


    public void setBasement(Basement basement) {
        this.basement = basement;
    }


    public void setRoof(Roof roof) {
        this.roof = roof;
    }

    public void setWall(Wall wall) {
        this.wall = wall;
    }
}
