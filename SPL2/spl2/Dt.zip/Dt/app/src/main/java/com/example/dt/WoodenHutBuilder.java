package com.example.dt;

public class WoodenHutBuilder implements HutBuilder {
    private Hut hut;

    public WoodenHutBuilder(Hut hut) {
        this.hut = new Hut();
    }

    @Override
    public void buildBasement() {

    }

    @Override
    public void buildRoof() {

    }

    @Override
    public void buildWall() {

    }

    @Override
    public Hut getHut() {
        return this.hut;
    }
}
