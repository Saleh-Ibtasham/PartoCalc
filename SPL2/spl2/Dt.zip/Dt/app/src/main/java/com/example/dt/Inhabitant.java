package com.example.dt;

public class Inhabitant {

    private String name;
    private String sex;
    private String status = "Unmarried";
    private String alertLevel = "The island is safe right now";
    private Inhabitant marriedTo = null;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAlertLevel() {
        return alertLevel;
    }

    public void setAlertLevel(String alertLevel) {
        this.alertLevel = alertLevel;
    }

    public Inhabitant getMarriedTo() {
        return marriedTo;
    }

    public void setMarriedTo(Inhabitant marriedTo) {
        this.marriedTo = marriedTo;
    }

    public void getAlert() {
        this.setAlertLevel("The island is in danger right now");
    }

    public void relief() {
        this.setAlertLevel("The island is safe right now");
    }

    public void marry(Inhabitant i){
        this.marriedTo = i;
        i.marry(this);
    }

    public  void undoMarry(Inhabitant i){
        this.marriedTo = null;
        i.marriedTo = null;
    }
}
