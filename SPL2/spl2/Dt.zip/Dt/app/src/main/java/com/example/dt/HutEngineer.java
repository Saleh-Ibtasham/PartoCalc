package com.example.dt;

public class HutEngineer {
    private HutBuilder hutBuilder;

    public HutEngineer(HutBuilder hutBuilder) {
        this.hutBuilder = hutBuilder;
    }

    public Hut getHut(){
        return this.hutBuilder.getHut();
    }

    public void constructHut(){
        this.hutBuilder.buildBasement();
        this.hutBuilder.buildRoof();
        this.hutBuilder.buildWall();
    }
}
