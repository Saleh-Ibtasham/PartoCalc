package com.example.dt;

class Flora {
    public String name;
    public int count;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
    public void grow(int i){
        int x = this.getCount() + i;
        this.setCount(x);
    }
    public void harvest(){
        int x = this.getCount()/2;
        this.setCount(x);
    }
}
