package com.example.dt;

public class TentBuilder implements HutBuilder {
    private Hut hut;

    public TentBuilder(Hut hut) {
        this.hut = new Hut();
    }

    @Override
    public void buildBasement() {

    }

    @Override
    public void buildRoof() {

    }

    @Override
    public void buildWall() {

    }

    @Override
    public Hut getHut() {
        return this.hut;
    }
}
