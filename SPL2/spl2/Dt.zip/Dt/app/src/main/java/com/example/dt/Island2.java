package com.example.dt;

public class Island2 extends IIsland {
    public Island2(City city) {
        this.setName("Island 2");
        this.setFlora(new Flora2());
        this.setFauna(new Fauna2());
        this.setEnvironment(new Environment2());
        generateInhabitants();
        setCity(city);
        setCafe(new Cafe(city));
        setReservoir(Reservoir.getReservoir());
    }
}

