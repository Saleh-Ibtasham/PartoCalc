package com.example.dt;

public class Reservoir {
    private static  Reservoir reservoir;

    private int waterLevel = 10000;

    public int getWaterLevel() {
        return waterLevel;
    }

    public void setWaterLevel(int waterLevel) {
        this.waterLevel = waterLevel;
    }

    private Reservoir() {
    }

    public static Reservoir getReservoir() {
        if(reservoir == null)
            reservoir = new Reservoir();
        return reservoir;
    }

    public void store(int i){
        int x = this.getWaterLevel() + i;
        if(x >= 10000)
            x = 10000;
        this.setWaterLevel(x);
    }

    public void useWater(int i){
        int x = this.getWaterLevel() - i;
        this.setWaterLevel(x);
    }
}
