package com.example.dt;

import java.util.ArrayList;

class City {
    private ArrayList<IIsland> islands = null;
    private ArrayList<String> latestNews = null;
    public void updateNews(String news, Cafe cafe) {
        IIsland island = cafe.getIsland();
        if(island instanceof Island1){

        }
        else{

        }
    }
    public void sendNews(String s){
        for(IIsland island: islands){
            island.getCafe().setCityNews(s);
        }
    }
}
