package com.example.dt;

public class Flora1 extends Flora {
    public Flora1() {
        this.setName("Island 1 flora");
        this.setCount(1500);
    }
}
