package com.example.dt;

public class Flora2 extends Flora {
    public Flora2() {
        this.setName("Island 2 flora");
        this.setCount(3500);
    }
}
