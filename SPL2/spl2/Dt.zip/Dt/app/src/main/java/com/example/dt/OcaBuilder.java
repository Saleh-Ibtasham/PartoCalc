package com.example.dt;

public class OcaBuilder implements HutBuilder {
    private Hut hut;

    public OcaBuilder(Hut hut) {
        this.hut = new Hut();
    }

    @Override
    public void buildBasement() {

    }

    @Override
    public void buildRoof() {

    }

    @Override
    public void buildWall() {

    }

    @Override
    public Hut getHut() {
        return this.hut;
    }
}
