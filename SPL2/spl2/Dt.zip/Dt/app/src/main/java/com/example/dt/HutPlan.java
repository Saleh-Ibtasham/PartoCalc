package com.example.dt;

public interface HutPlan {
    public void setBasement(Basement basement);
    public void setRoof(Roof roof);
    public void setWall(Wall wall);
}
