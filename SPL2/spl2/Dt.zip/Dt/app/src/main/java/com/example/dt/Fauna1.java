package com.example.dt;

public class Fauna1 extends Fauna {
    public Fauna1() {
        this.setName("Islaand 1 fauna");
        this.setCount(2500);
    }
}
