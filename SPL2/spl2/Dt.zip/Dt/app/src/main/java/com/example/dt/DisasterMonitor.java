package com.example.dt;

import java.util.ArrayList;
import java.util.Random;

public class DisasterMonitor {
    private ArrayList<Inhabitant> people = null;

    public ArrayList<Inhabitant> getPeople() {
        return people;
    }

    public void setPeople(ArrayList<Inhabitant> people) {
        this.people = people;
    }

    public void getLatestNews(){
        Random random = new Random();
        int x = random.nextInt(2);
        if((x%2) == 1){
            alert();
        }
        else{
            greenSignal();
        }
    }

    public void alert(){
        for(Inhabitant i: people){
            i.getAlert();
        }
    }

    public void greenSignal(){
        for(Inhabitant i: people){
            i.relief();
        }
    }
}
