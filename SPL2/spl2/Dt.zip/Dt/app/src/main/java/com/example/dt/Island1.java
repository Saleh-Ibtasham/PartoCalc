package com.example.dt;

import java.util.ArrayList;
import java.util.Random;

public class Island1 extends IIsland {
    public Island1(City city) {
        setName("Island 1");
        setFauna(new Fauna1());
        setFlora(new Flora1());
        setEnvironment(new Environment1());
        generateInhabitants();
        setCity(city);
        setCafe(new Cafe(city));
        setReservoir(Reservoir.getReservoir());
    }


}
