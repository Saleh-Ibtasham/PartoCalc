package com.example.dt;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class HabitatFactory implements Parcelable {

    private IIsland island1 = null;
    private IIsland island2 = null;
    private City city = null;

    protected HabitatFactory() {
    }

    public static final Creator<HabitatFactory> CREATOR = new Creator<HabitatFactory>() {
        @Override
        public HabitatFactory createFromParcel(Parcel in) {
            return new HabitatFactory();
        }

        @Override
        public HabitatFactory[] newArray(int size) {
            return new HabitatFactory[size];
        }
    };

    public City getCity(){
        if(city == null)
            city = new City();
        return city;
    }

    public IIsland getIsland(int i){

        if(i==1){
            if(island1 == null)
                island1 = new Island1(this.city);
            return island1;
        }
        else{
            if(island2 == null)
                island2 = new Island2(this.city);
            return  island2;
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
    }
}
