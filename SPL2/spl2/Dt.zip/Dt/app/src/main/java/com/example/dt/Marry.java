package com.example.dt;

public class Marry {

    private Inhabitant i;

    public Marry(Inhabitant i) {
        this.i = i;
    }

    public void execute(Inhabitant x){
        this.i.marry(x);
    }
    public void undoVow(Inhabitant x){
        this.i.undoMarry(x);
    }

    public Inhabitant getI() {
        return i;
    }
}
