package com.example.dt;

public interface HutBuilder {
    public void buildBasement();
    public void buildRoof();
    public void buildWall();
    public Hut getHut();
}
