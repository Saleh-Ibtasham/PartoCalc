package com.example.dt;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.io.Serializable;

public class IslandView extends AppCompatActivity {
    Button button1,button2,button3;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.island_view);
        button1 = (Button) findViewById(R.id.island1Map);
        button2 = (Button) findViewById(R.id.island2Map);

        final HabitatFactory habitatFactory = (HabitatFactory) getIntent().getParcelableExtra("Factory");

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(IslandView.this,Island1View.class);
                intent.putExtra("Factory", habitatFactory);
                startActivity(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(IslandView.this,Island2View.class);
                intent.putExtra("Factory",habitatFactory);
                startActivity(intent);
            }
        });

    }
}
