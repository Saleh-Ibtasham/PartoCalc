package com.example.dt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity {

    Button cityBtn,island1Btn,island2Btn, islndView;
    ImageView water,island1Image,island2Image,cityImage;
    HabitatFactory habitatFactory = null;
    City city = null;
    IIsland island1,island2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cityBtn = findViewById(R.id.button);
        island1Btn = findViewById(R.id.button3);
        island2Btn = findViewById(R.id.button4);
        islndView = findViewById(R.id.button2);
        water = findViewById(R.id.water);
        island1Image = findViewById(R.id.island1);
        island2Image = findViewById(R.id.island2);
        cityImage = findViewById(R.id.city);

        habitatFactory = new HabitatFactory();

        int waterResource = getResources().getIdentifier("@drawable/water",null,this.getPackageName());
        final int island1Resource = getResources().getIdentifier("@drawable/island1",null,getPackageName());
        final int island2Resource = getResources().getIdentifier("@drawable/island2",null,getPackageName());
        final int cityResource = getResources().getIdentifier("@drawable/city",null,getPackageName());

        water.setImageResource(waterResource);

        cityBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                city = habitatFactory.getCity();
                cityImage.setImageResource(cityResource);
                Toast.makeText(getApplicationContext(),"City has been created", Toast.LENGTH_LONG).show();
            }
        });

        island1Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if(city == null)
                        Toast.makeText(getApplicationContext(),"Create the city first",Toast.LENGTH_LONG).show();
                    else{
                        island1 = habitatFactory.getIsland(1);
                        Toast.makeText(getApplicationContext(),"Island1 created",Toast.LENGTH_LONG).show();
                        island1Image.setImageResource(island1Resource);
                    }

            }
        });

        island2Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(city == null)
                    Toast.makeText(getApplicationContext(),"Create the city first",Toast.LENGTH_LONG).show();
                else{
                    island2 = habitatFactory.getIsland(2);
                    Toast.makeText(getApplicationContext(),"Island2 created",Toast.LENGTH_LONG).show();
                    island2Image.setImageResource(island2Resource);
                }
            }
        });

        islndView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((city == null)||(island1 == null)||(island2 == null))
                    Toast.makeText(getApplicationContext(),"Create the habitats first",Toast.LENGTH_LONG).show();
                else{
                    Intent intent = new Intent(MainActivity.this, IslandView.class);
                    intent.putExtra("Factory", habitatFactory);
                    startActivity(intent);
                }

            }
        });
    }


}
