package com.example.dt;

class Fauna {
    private String name;
    private int count;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void breed(int newBreed){
        int newCount = this.getCount() + newBreed;
        this.setCount(newCount);
    }

    public void hunt(int hunted){
        int newCount = this.getCount() - hunted;
        this.setCount(newCount);
    }
}
