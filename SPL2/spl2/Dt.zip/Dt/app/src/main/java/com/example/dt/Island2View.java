package com.example.dt;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class Island2View extends AppCompatActivity {
    Button grow,harvest,breed,hunt,animation,useWater;
    ArrayList<ImageView> trees = new ArrayList<>();
    ArrayList<ImageView> animals = new ArrayList<>();
    EditText flora,fauna,inhabitants,reservoir;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.island2_view);

        grow = (Button) findViewById(R.id.grow);
        harvest = (Button) findViewById(R.id.harvest);
        breed = (Button) findViewById(R.id.breed);
        hunt = (Button) findViewById(R.id.hunt);
        animation = (Button) findViewById(R.id.environment);
        useWater = (Button) findViewById(R.id.usewater);
        flora = (EditText) findViewById(R.id.flora);
        fauna = (EditText) findViewById(R.id.fauna);
        inhabitants = (EditText) findViewById(R.id.inhabitants);
        reservoir = (EditText) findViewById(R.id.reservoir);


        generateTrees();
        generateAnimals();

        HabitatFactory habitatFactory = (HabitatFactory) getIntent().getParcelableExtra("Factory");
        final IIsland island =  habitatFactory.getIsland(2);

        flora.setText(Integer.toString(island.getFlora().getCount()));
        fauna.setText(Integer.toString(island.getFauna().getCount()));
        inhabitants.setText(Integer.toString(island.getPeopleCount()));
        reservoir.setText(Integer.toString(island.getReservoir().getWaterLevel()));

        grow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                island.getFlora().grow(200);
                flora.setText(Integer.toString(island.getFlora().getCount()));
                int i =0 ;
                for(ImageView im : trees){
                    if(i==6)
                        break;
                    im.setVisibility(View.VISIBLE);
                    i++;
                }
            }
        });

        harvest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                island.getFlora().harvest();
                flora.setText(Integer.toString(island.getFlora().getCount()));
                int i =0 ;
                for(ImageView im : trees){
                    if(i==6)
                        break;
                    im.setVisibility(View.INVISIBLE);
                    i++;
                }

            }
        });

        breed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                island.getFauna().breed(200);
                fauna.setText(Integer.toString(island.getFauna().getCount()));
                int i =0 ;
                for(ImageView im : animals){
                    if(i==3)
                        break;
                    im.setVisibility(View.VISIBLE);
                    i++;
                }
            }
        });

        hunt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(island.getFauna().getCount() < 500)
                    Toast.makeText(getApplicationContext(),"Should not hunt anymore!!",Toast.LENGTH_LONG).show();
                else{

                    island.getFauna().hunt(300);
                    fauna.setText(Integer.toString(island.getFauna().getCount()));
                    int i =0 ;
                    for(ImageView im : animals){
                        if(i==3)
                            break;
                        im.setVisibility(View.INVISIBLE);
                        i++;
                    }
                }
            }
        });

        animation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                weatherView.setWeather(Constants.weatherStatus.RAIN).setLifeTime(2000).setFadeOutTime(1000).setParticles(50).setFPS(60).setAngle(-5).startAnimation();
                Toast.makeText(getApplicationContext(),"It's raining!!!",Toast.LENGTH_LONG).show();
                island.getReservoir().store(5000);
                reservoir.setText(Integer.toString(island.getReservoir().getWaterLevel()));
            }
        });

        useWater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(island.getReservoir().getWaterLevel() < 2000)
                    Toast.makeText(getApplicationContext(),"You can't use the reservoir right now, Please pray!!!",Toast.LENGTH_LONG).show();
                else{
                    island.getReservoir().useWater(400);
                    Toast.makeText(getApplicationContext(),"Inhabitants are using water",Toast.LENGTH_LONG).show();
                    reservoir.setText(Integer.toString(island.getReservoir().getWaterLevel()));
                }
            }
        });
    }

    private void generateAnimals() {
        for(int i=1 ; i<6; i++){
            String a = "animal"+Integer.toString(i);
            int resID = getResources().getIdentifier(a,"id",getPackageName());
            ImageView imageView = (ImageView) findViewById(resID);
            animals.add(imageView);
        }
    }

    private void generateTrees() {
        for(int i=1 ; i<13; i++){
            String a = "tree"+Integer.toString(i);
            int resID = getResources().getIdentifier(a,"id",getPackageName());
            ImageView imageView = (ImageView) findViewById(resID);
            trees.add(imageView);
        }
    }
}

