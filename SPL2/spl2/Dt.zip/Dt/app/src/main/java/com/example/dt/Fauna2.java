package com.example.dt;

public class Fauna2 extends Fauna {
    public Fauna2() {
        this.setName("Island 2 fauna");
        this.setCount(1200);
    }
}
