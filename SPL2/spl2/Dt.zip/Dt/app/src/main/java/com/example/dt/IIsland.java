package com.example.dt;


import java.util.ArrayList;
import java.util.Random;

public abstract class IIsland {
    private String name;
    private Flora flora;
    private Fauna fauna;
    private Environment environment;
    private ArrayList<Inhabitant> people;
    private ArrayList<Hut> huts;
    private City city;
    private String cityNews;
    private Cafe cafe;
    private Reservoir reservoir;

    public Reservoir getReservoir() {
        return reservoir;
    }

    public void setReservoir(Reservoir reservoir) {
        this.reservoir = reservoir;
    }

    public Cafe getCafe() {
        return cafe;
    }

    public void setCafe(Cafe cafe) {
        this.cafe = cafe;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public String getCityNews() {
        return cityNews;
    }

    public ArrayList<Inhabitant> getPeople() {
        return people;
    }

    public void setPeople(ArrayList<Inhabitant> people) {
        this.people = people;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Flora getFlora() {
        return flora;
    }

    public void setFlora(Flora flora) {
        this.flora = flora;
    }

    public Fauna getFauna() {
        return fauna;
    }

    public void setFauna(Fauna fauna) {
        this.fauna = fauna;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }

    public  void setCityNews(String s){this.cityNews = s;}

    public int getPeopleCount(){
        return this.people.size();
    }

    public void generateInhabitants() {
        ArrayList <Inhabitant> persons = new ArrayList<>();
        Random random = new Random();
        int x = random.nextInt(1500);
        for(int i = 0; i<1500; i++)
        {
            Inhabitant a = null;
            String name = "Inhabitant" + Integer.toString(i+1);
            if((x%2) == 1){
                a = new SoftEngg();
                a.setName(name);
                a.setSex(generateSex());
            }
            else {
                a = new Inhabitant();
                a.setName(name);
                a.setSex(generateSex());
            }
            persons.add(a);
        }
        this.setPeople(persons);

    }

    private String generateSex() {
        Random random = new Random();
        int x = random.nextInt(2);
        if(x == 1){
            return "F";
        }
        else
            return "M";
    }

}
