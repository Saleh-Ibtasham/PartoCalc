package com.example.dt;

public class Environment2 extends Environment {
    @Override
    public void animateEnv() {

    }
}
