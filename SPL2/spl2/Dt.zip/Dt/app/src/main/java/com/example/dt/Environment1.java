package com.example.dt;

public class Environment1 extends Environment {
    @Override
    public void animateEnv() {

    }
}
