package com.example.dt;

public class Priest {
    private Marry inhabitant1, inhabitant2;

    public Priest(Marry inhabitant1, Marry inhabitant2) {
        this.inhabitant1 = inhabitant1;
        this.inhabitant2 = inhabitant2;
    }

    public void superviseMarriage(){
        this.inhabitant1.execute(this.inhabitant2.getI());
        this.inhabitant2.execute(this.inhabitant1.getI());
    }

    public void undoMarriage(){
        this.inhabitant1.undoVow(this.inhabitant2.getI());
        this.inhabitant2.undoVow(this.inhabitant1.getI());
    }
}
