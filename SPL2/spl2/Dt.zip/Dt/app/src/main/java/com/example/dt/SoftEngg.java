package com.example.dt;

public class SoftEngg extends Inhabitant {
    private Cafe cafe;

    public Cafe getCafe() {
        return cafe;
    }

    public void setCafe(Cafe cafe) {
        this.cafe = cafe;
    }

    public void sendNews(String s){
        this.cafe.generateNews(s);
    }
}
